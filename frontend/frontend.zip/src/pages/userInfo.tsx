import React, { useState, useEffect} from "react";

const UserInfo : React.FC = () => {
    return (
        <div>
            <h1>Real Time Clock</h1>
        </div>
    )
}   

export default UserInfo;